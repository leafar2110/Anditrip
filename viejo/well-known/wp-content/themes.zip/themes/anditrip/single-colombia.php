<?php  header("Location: https://anditrip.com"); //redirection home.php?>
