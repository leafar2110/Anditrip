<?php 
 	$currentlang = get_bloginfo('language');
 	if($currentlang=="en-US") {
    	//Destintions
        	$more_destinations = 'More Destinations';
        	$plans = 'Plans';
        	$domestic = 'Domestic flight tickets';
        	$hotel = 'Hotel';
  	} else {
        //Items Persons
        	$more_destinations = '在波在波在波';
        	$plans = '在波';
        	$domestic = '在波在波在波在波';
        	$hotel = '在波';
			
  }
  
  ?>
<!--end traduction-->