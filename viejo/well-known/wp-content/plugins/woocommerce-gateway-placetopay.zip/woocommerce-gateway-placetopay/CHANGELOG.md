## Changelog

### [2.13.1] - 2018-05-22
- Upgraded redirection dependency for support multiples currencies in validation
- Added support for cancelled orders
- Added support for countries Colombia, Ecuador(CO, EC) 

### [2.11.6] - 2017-12-01
- Added status order to the page of return and a link to PlacetoPay for view order detail
- Updated the file of translations `es_CO`
- Added field list in configuration for the expiration in minutes
- Added product names to the description of the request for PlacetoPay
- Added validations to field of the checkout
- Updated logo PlacetoPay
- Added link in the logo to PlacetoPay site

### [2.6.6] - 2017-11-01
- Fixed alert message was displayed in debug mode of WordPress